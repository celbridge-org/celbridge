"""RPC client for calling FROM Python TO C#.

This class contains methods that call C# methods via JSON-RPC.
When Python needs to call a C# method, it uses this client.

Architecture:
- rpc_service.py: Infrastructure (pipes, server, transport)
- rpc_handler.py: Methods called FROM C# TO Python
- rpc_client.py: Methods that call FROM Python TO C# (this file)
"""

import logging

from celbridge_host.rpc_service import call_csharp_method, RpcError

logger = logging.getLogger(__name__)


class RpcClient:
    """Client for making RPC calls from Python to C#.
    
    Methods in this class send JSON-RPC requests to C# handlers.
    This mirrors the C# RPCClient class which contains methods that call Python.
    
    All transport and protocol details are handled by rpc_service.call_csharp_method().
    """

    def __init__(self):
        """Initialize the RPC client."""
        pass

    def log_message(self, message: str) -> bool:
        """Send a log message to the C# host.
        
        This calls the C# LogMessageAsync method via JSON-RPC.
        
        Args:
            message: The log message to send
            
        Returns:
            True if the message was sent successfully, False otherwise
        """
        try:
            call_csharp_method("LogMessageAsync", message=message)
            return True
        except RpcError as e:
            logger.error(f"Failed to log message: {e}")
            return False
