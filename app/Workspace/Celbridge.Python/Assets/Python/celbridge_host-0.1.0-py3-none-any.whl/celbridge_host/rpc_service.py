"""JSON-RPC service for celbridge_host - provides bidirectional RPC communication with C#.

This module provides the infrastructure for JSON-RPC communication over named pipes:
- NamedPipeHandler: Low-level pipe I/O with header-delimited messages
- CelbridgeRpcService: Server thread that listens for incoming RPC calls from C#
- Global pipe handler access: Enables RpcClient to send outgoing calls to C#

The service supports bidirectional communication:
- Incoming: C# -> Python (handled by methods in rpc_handler.py via @method decorators)
- Outgoing: Python -> C# (initiated by RpcClient via call_csharp_method())
"""

import os
import json
import logging
import threading
from typing import Optional, Any

import win32pipe  # type: ignore
import win32file  # type: ignore
import pywintypes  # type: ignore
from jsonrpcserver import dispatch
from jsonrpcclient import request_json, parse_json, Ok, Error as RpcClientError

# Import rpc_handler to register its @method decorated functions
from celbridge_host import rpc_handler  # noqa: F401

# Configure logging
logger = logging.getLogger(__name__)

# Global server instance
_rpc_service: Optional['CelbridgeRpcService'] = None
_service_lock = threading.Lock()

# Global pipe handler for outgoing requests to C#
_pipe_handler: Optional['NamedPipeHandler'] = None
_pipe_handler_lock = threading.Lock()


class NamedPipeHandler:
    """Handles reading and writing header-delimited messages over Windows named pipes."""

    def __init__(self, pipe_handle):
        """Initialize with a connected named pipe handle.
        
        Args:
            pipe_handle: Win32 pipe handle from CreateNamedPipe/ConnectNamedPipe
        """
        self.pipe_handle = pipe_handle

    def read_message(self) -> Optional[str]:
        """Read a header-delimited message from the pipe.
        
        Returns:
            The JSON-RPC message string, or None if connection closed
        """
        try:
            # Read headers until we find \r\n\r\n
            headers = b""
            while b"\r\n\r\n" not in headers:
                chunk = self._read_bytes(1)
                if not chunk:
                    return None
                headers += chunk
            
            # Parse Content-Length header
            headers_str = headers.decode('utf-8')
            content_length = None
            for line in headers_str.split('\r\n'):
                if line.startswith('Content-Length:'):
                    content_length = int(line.split(':', 1)[1].strip())
                    break
            
            if content_length is None:
                logger.error("No Content-Length header found")
                return None
            
            # Read the exact number of bytes specified
            message_bytes = self._read_bytes(content_length)
            if not message_bytes or len(message_bytes) != content_length:
                logger.error(f"Failed to read complete message (expected {content_length} bytes)")
                return None
            
            return message_bytes.decode('utf-8')
            
        except Exception as e:
            logger.error(f"Error reading message: {e}")
            return None

    def write_message(self, message: str) -> bool:
        """Write a header-delimited message to the pipe.
        
        Args:
            message: The JSON-RPC response string
            
        Returns:
            True if write succeeded, False otherwise
        """
        try:
            message_bytes = message.encode('utf-8')
            content_length = len(message_bytes)
            headers = f"Content-Length: {content_length}\r\n\r\n".encode('utf-8')
            
            # Write headers + message
            full_message = headers + message_bytes
            win32file.WriteFile(self.pipe_handle, full_message)
            return True
            
        except Exception as e:
            logger.error(f"Error writing message: {e}")
            return False

    def _read_bytes(self, count: int) -> Optional[bytes]:
        """Read exactly count bytes from the pipe.
        
        Args:
            count: Number of bytes to read
            
        Returns:
            The bytes read, or None if connection closed
        """
        try:
            result, data = win32file.ReadFile(self.pipe_handle, count)
            if result == 0:  # Success
                # Ensure we return bytes, not str
                if isinstance(data, str):
                    return data.encode('utf-8')
                return data
            return None
        except pywintypes.error as e:
            if e.winerror == 109:  # ERROR_BROKEN_PIPE
                return None
            raise
            raise


class CelbridgeRpcService:
    """JSON-RPC server that runs in a background thread and communicates over named pipes."""

    def __init__(self, pipe_name: str):
        """Initialize the RPC server.
        
        Args:
            pipe_name: Name of the Windows named pipe (without \\\\.\\pipe\\ prefix)
        """
        self.pipe_name = f"\\\\.\\pipe\\{pipe_name}"
        self.running = False
        self.thread: Optional[threading.Thread] = None
        logger.info(f"RPC server initialized for pipe: {self.pipe_name}")

    def start(self):
        """Start the RPC server in a background thread."""
        if self.running:
            logger.warning("RPC server already running")
            return
        
        self.running = True
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()
        logger.info("RPC server started")

    def stop(self):
        """Stop the RPC server."""
        self.running = False
        if self.thread:
            # Note: We don't join the thread because it might be blocked on pipe operations
            # The daemon flag ensures it won't prevent process exit
            logger.info("RPC server stopped")

    def _run(self):
        """Main server loop that handles client connections."""
        while self.running:
            pipe_handle = None
            try:
                # Create named pipe
                pipe_handle = win32pipe.CreateNamedPipe(
                    self.pipe_name,
                    win32pipe.PIPE_ACCESS_DUPLEX,
                    win32pipe.PIPE_TYPE_BYTE | win32pipe.PIPE_READMODE_BYTE | win32pipe.PIPE_WAIT,
                    1,  # Max instances
                    65536,  # Out buffer size
                    65536,  # In buffer size
                    0,  # Default timeout
                    None  # type: ignore  # Security attributes
                )
                
                logger.info(f"Waiting for client connection on {self.pipe_name}...")
                
                # Wait for client to connect
                win32pipe.ConnectNamedPipe(pipe_handle, None)
                logger.info("Client connected")
                
                # Handle requests from this client
                self._handle_client(pipe_handle)
                
            except pywintypes.error as e:
                if self.running:
                    logger.error(f"Pipe error: {e}")
            except Exception as e:
                if self.running:
                    logger.error(f"Server error: {e}")
            finally:
                if pipe_handle:
                    try:
                        win32file.CloseHandle(pipe_handle)
                    except:
                        pass

    def _handle_client(self, pipe_handle):
        """Handle requests from a connected client.
        
        Args:
            pipe_handle: Connected pipe handle
        """
        global _pipe_handler
        
        handler = NamedPipeHandler(pipe_handle)
        
        # Store the pipe handler globally for outgoing requests
        with _pipe_handler_lock:
            _pipe_handler = handler
        
        try:
            while self.running:
                # Read request
                request_str = handler.read_message()
                if not request_str:
                    logger.info("Client disconnected")
                    break
                
                logger.debug(f"Received request: {request_str}")
                
                try:
                    # Dispatch to appropriate method and get response
                    response_str = dispatch(request_str)
                    logger.debug(f"Sending response: {response_str}")
                    
                    # Send response
                    if not handler.write_message(response_str):
                        logger.error("Failed to write response")
                        break
                        
                except Exception as e:
                    logger.error(f"Error processing request: {e}")
                    # Send error response
                    error_response = json.dumps({
                        "jsonrpc": "2.0",
                        "error": {
                            "code": -32603,
                            "message": f"Internal error: {str(e)}"
                        },
                        "id": None
                    })
                    handler.write_message(error_response)
        finally:
            # Clear the global pipe handler when client disconnects
            with _pipe_handler_lock:
                _pipe_handler = None


def initialize_rpc_service() -> bool:
    """Initialize and start the RPC server if CELBRIDGE_RPC_PIPE is set.
    
    Returns:
        True if server was started, False otherwise
    """
    global _rpc_service
    
    pipe_name = os.environ.get('CELBRIDGE_RPC_PIPE')
    if not pipe_name:
        logger.info("CELBRIDGE_RPC_PIPE not set, RPC server not started")
        return False
    
    with _service_lock:
        if _rpc_service is not None:
            logger.warning("RPC server already initialized")
            return False
        
        try:
            _rpc_service = CelbridgeRpcService(pipe_name)
            _rpc_service.start()
            logger.info(f"RPC server initialized and started on pipe: {pipe_name}")
            return True
        except Exception as e:
            logger.error(f"Failed to initialize RPC server: {e}")
            return False


def shutdown_rpc_service():
    """Shutdown the RPC server."""
    global _rpc_service
    
    with _service_lock:
        if _rpc_service is not None:
            _rpc_service.stop()
            _rpc_service = None
            logger.info("RPC server shutdown complete")


def get_rpc_service() -> Optional[CelbridgeRpcService]:
    """Get the current RPC server instance.
    
    Returns:
        The RPC server instance, or None if not initialized
    """
    return _rpc_service


def get_pipe_handler() -> Optional['NamedPipeHandler']:
    """Get the current pipe handler for sending requests to C#.
    
    Returns:
        The pipe handler instance, or None if no client is connected
    """
    with _pipe_handler_lock:
        return _pipe_handler


class RpcError(Exception):
    """Exception raised when an RPC call fails."""
    pass


def call_csharp_method(method: str, **params) -> Any:
    """Call a C# method via JSON-RPC.
    
    Transport-agnostic RPC call that handles all low-level details including
    pipe I/O, JSON-RPC protocol, request/response formatting, and error handling.
    
    This is the infrastructure method used by RpcClient to make outgoing calls.
    
    Args:
        method: The C# method name to call
        **params: Method parameters as keyword arguments
        
    Returns:
        The result from the RPC call (can be None for void methods)
        
    Raises:
        RpcError: If the RPC call fails (connection, transport, or protocol error)
    """
    # Get the transport (pipe handler)
    pipe_handler = get_pipe_handler()
    if pipe_handler is None:
        raise RpcError(f"Cannot call '{method}': No active pipe connection to C#")
    
    # Build JSON-RPC request
    request_str = request_json(method, params=params)
    logger.debug(f"RPC call to C#: {method}({params})")
    
    # Send request
    if not pipe_handler.write_message(request_str):
        raise RpcError(f"Failed to send RPC request: {method}")
    
    # Receive response
    response_str = pipe_handler.read_message()
    if not response_str:
        raise RpcError(f"Failed to receive RPC response: {method}")
    
    # Parse JSON-RPC response
    response = parse_json(response_str)
    
    if isinstance(response, Ok):
        logger.debug(f"RPC call succeeded: {method}")
        return response.result
    elif isinstance(response, RpcClientError):
        raise RpcError(f"RPC error in '{method}': {response.message} (code: {response.code})")
    else:
        raise RpcError(f"Unexpected response type for '{method}': {type(response)}")
