"""RPC handler for methods called FROM C# TO Python.

This module contains methods that are exposed to C# clients via JSON-RPC.
When C# calls a Python method, it's handled here.

Methods are registered with jsonrpcserver using the @method decorator,
which makes them automatically available to the RPC service.

Architecture:
- rpc_service.py: Infrastructure (pipes, server, transport)
- rpc_handler.py: Methods called FROM C# TO Python (this file)
- rpc_client.py: Methods that call FROM Python TO C#
"""

import sys
import logging
import platform
from typing import Dict, Any

from jsonrpcserver import method, Result, Success, Error

logger = logging.getLogger(__name__)


# RPC methods exposed to C# - registered with @method decorator
# These are called directly by jsonrpcserver's dispatch() in rpc_service.py

@method
def get_version() -> Result:
    """Return the celbridge package version.
    
    Returns:
        Success with version string, or Error on failure
    """
    try:
        from celbridge_host.celbridge_host import CelbridgeHost
        cel = CelbridgeHost()
        result = cel.version()
        # Extract version string from result dict
        version_str = result.get('version', 'unknown') if isinstance(result, dict) else str(result)
        return Success(version_str)
    except Exception as e:
        logger.error(f"Error in get_version(): {e}")
        return Error(code=-32603, message=f"Internal error: {str(e)}")


@method
def get_system_info() -> Result:
    """Get Python system information.
    
    Returns:
        Success with system info dict, or Error on failure
    """
    try:
        info = {
            "OS": platform.system(),
            "PythonVersion": sys.version.split()[0],
            "Platform": platform.platform()
        }
        return Success(info)
    except Exception as e:
        logger.error(f"Error in get_system_info(): {e}")
        return Error(code=-32603, message=f"Internal error: {str(e)}")
