# Fake Data Example

This example demonstrates using the `faker` Python package to quickly generate fake user data for testing. 

1. Open the **fake_data.xlsx** document.
2. In the Inspector panel, click the **Run script** button.
3. Note that the spreadsheet has updated with a new set of fake data.

The number specified in the **Arguments** controls the number of generated rows. Try changing this value and running the script again.