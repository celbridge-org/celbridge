import json

import pytest

from celbridge.cel_proxy import CelError

from .helpers import close_if_open, delete_if_exists


@pytest.fixture(autouse=True)
def workspace(explorer, document):
    delete_if_exists(explorer, "TestExplorer")
    explorer.create_folder("TestExplorer")
    yield
    close_if_open(document, "TestExplorer/hello.txt")
    close_if_open(document, "TestExplorer/original.txt")
    close_if_open(document, "TestExplorer/moved.txt")
    delete_if_exists(explorer, "TestExplorer")


def _create_archive_source(explorer, file):
    explorer.create_folder("TestExplorer/archive_source")
    file.write("TestExplorer/archive_source/file.txt", "archive content\n")


class TestExplorer:

    def test_create_file(self, explorer, file):
        explorer.create_file("TestExplorer/hello.txt")
        items = file.list_contents("TestExplorer")
        names = [i["name"] for i in items]
        assert "hello.txt" in names

    def test_create_folder(self, explorer, file):
        explorer.create_folder("TestExplorer/subfolder")
        items = file.list_contents("TestExplorer")
        names = [i["name"] for i in items]
        assert "subfolder" in names

    def test_select(self, explorer):
        explorer.create_file("TestExplorer/hello.txt")
        explorer.select("TestExplorer/hello.txt")

    def test_get_state(self, explorer):
        explorer.create_file("TestExplorer/hello.txt")
        explorer.select("TestExplorer/hello.txt")
        ctx = explorer.get_state()
        assert "selectedResource" in ctx
        assert "expandedFolders" in ctx

    def test_expand_and_collapse_folder(self, explorer):
        explorer.expand_folder("TestExplorer", expanded=True)
        explorer.expand_folder("TestExplorer", expanded=False)

    def test_collapse_all(self, explorer):
        explorer.expand_folder("TestExplorer", expanded=True)
        explorer.collapse_all()

    def test_copy(self, explorer, file):
        explorer.create_file("TestExplorer/hello.txt")
        explorer.copy("TestExplorer/hello.txt", "TestExplorer/hello_copy.txt")
        items = file.list_contents("TestExplorer")
        names = [i["name"] for i in items]
        assert "hello_copy.txt" in names

    def test_move(self, explorer, file):
        explorer.create_file("TestExplorer/original.txt")
        explorer.move("TestExplorer/original.txt", "TestExplorer/moved.txt")
        items = file.list_contents("TestExplorer")
        names = [i["name"] for i in items]
        assert "moved.txt" in names
        assert "original.txt" not in names

    def test_move_preserves_referential_integrity(self, explorer, file):
        # The reference-rewrite cascade in IResourceFileSystem.MoveAsync must
        # rewrite the literal reference in every referencer when the target
        # moves. The referencer is .json (an allowlisted scanner extension) so
        # the cascade actually walks it; .md would be invisible to the scanner.
        file.write(
            "TestExplorer/source.json",
            "{\"target\": \"project:TestExplorer/target.md\"}",
        )
        file.write("TestExplorer/target.md", "Target body.\n")

        explorer.move("TestExplorer/target.md", "TestExplorer/renamed.md")

        rewritten = file.read("TestExplorer/source.json")["content"]
        assert "project:TestExplorer/renamed.md" in rewritten
        assert "project:TestExplorer/target.md" not in rewritten

    def test_delete_with_break_references_leaves_literal_in_place(self, explorer, file):
        # Deleting a referenced resource under break_references must leave the
        # source file's reference literal untouched (the cascade does not run);
        # the reference now points at a missing target.
        file.write(
            "TestExplorer/has_ref.json",
            "{\"target\": \"project:TestExplorer/will_delete.md\"}",
        )
        file.write("TestExplorer/will_delete.md", "Doomed.\n")

        explorer.delete(
            "TestExplorer/will_delete.md",
            reference_policy="break_references",
        )

        residual = file.read("TestExplorer/has_ref.json")["content"]
        assert "project:TestExplorer/will_delete.md" in residual

    def test_undo_redo(self, explorer):
        explorer.create_file("TestExplorer/undo_test.txt")
        explorer.undo()
        explorer.redo()

    def test_delete(self, explorer, file):
        explorer.create_file("TestExplorer/to_delete.txt")
        explorer.delete("TestExplorer/to_delete.txt")
        items = file.list_contents("TestExplorer")
        names = [i["name"] for i in items]
        assert "to_delete.txt" not in names

    def test_duplicate(self, explorer, file):
        # Silent by default: the tool generates the unique name rather than asking for one.
        explorer.create_file("TestExplorer/original.txt")
        explorer.duplicate("TestExplorer/original.txt")

        items = file.list_contents("TestExplorer")
        names = [i["name"] for i in items]
        assert "original.txt" in names
        assert "original - Copy.txt" in names

    def test_duplicate_missing_resource(self, explorer):
        with pytest.raises(CelError):
            explorer.duplicate("TestExplorer/not_here.txt")

    def test_archive(self, explorer, file):
        _create_archive_source(explorer, file)
        result = explorer.archive(
            "TestExplorer/archive_source", "TestExplorer/test_archive.zip", overwrite=True
        )
        assert result["entries"] > 0
        assert result["size"] > 0

    def test_archive_filtered(self, explorer, file):
        _create_archive_source(explorer, file)
        result = explorer.archive(
            "TestExplorer/archive_source",
            "TestExplorer/test_archive_filtered.zip",
            include="*.txt",
            overwrite=True,
        )
        assert result["entries"] >= 1

    def test_unarchive(self, explorer, file):
        _create_archive_source(explorer, file)
        explorer.archive(
            "TestExplorer/archive_source", "TestExplorer/test_archive.zip", overwrite=True
        )
        explorer.create_folder("TestExplorer/archive_extract")
        result = explorer.unarchive(
            "TestExplorer/test_archive.zip", "TestExplorer/archive_extract", overwrite=True
        )
        assert result["entries"] > 0

    def test_archive_invalid_source(self, explorer):
        with pytest.raises(CelError):
            explorer.archive("\\invalid", "TestExplorer/test_archive.zip")

    def test_archive_invalid_destination(self, explorer, file):
        _create_archive_source(explorer, file)
        with pytest.raises(CelError):
            explorer.archive("TestExplorer/archive_source", "\\invalid")

    def test_unarchive_invalid_archive(self, explorer):
        with pytest.raises(CelError):
            explorer.unarchive("\\invalid", "TestExplorer/archive_extract")

    # explorer.rename always opens the rename dialog. The key check below runs before
    # the dialog opens, so it needs no answer.
    def test_rename_invalid_resource_key(self, explorer):
        with pytest.raises(CelError):
            explorer.rename("\\backslash\\not\\allowed")

    def test_create_file_invalid_resource_key(self, explorer):
        with pytest.raises(CelError):
            explorer.create_file("\\backslash\\not\\allowed")

    def test_create_folder_invalid_resource_key(self, explorer):
        with pytest.raises(CelError):
            explorer.create_folder("/leading/slash")

    def test_copy_invalid_source(self, explorer):
        with pytest.raises(CelError):
            explorer.copy("\\invalid", "TestExplorer/dest.txt")

    def test_move_invalid_destination(self, explorer):
        explorer.create_file("TestExplorer/hello.txt")
        with pytest.raises(CelError):
            explorer.move("TestExplorer/hello.txt", "\\invalid")

    def test_select_invalid_resource_key(self, explorer):
        with pytest.raises(CelError):
            explorer.select("\\invalid")

    def test_expand_folder_invalid_resource_key(self, explorer):
        with pytest.raises(CelError):
            explorer.expand_folder("\\invalid")

    def test_nested_folder_operations(self, explorer, file):
        explorer.create_folder("TestExplorer/a/b/c")
        explorer.create_file("TestExplorer/a/b/c/deep.txt")
        items = file.list_contents("TestExplorer/a/b/c")
        names = [i["name"] for i in items]
        assert "deep.txt" in names

    def test_create_file_with_cel_extension_rejected(self, explorer):
        # The .cel extension is reserved for project metadata sidecars; agents
        # cannot create files in that namespace directly.
        with pytest.raises(CelError, match="(?i)\\.cel extension is reserved"):
            explorer.create_file("TestExplorer/reserved.cel")

    def test_copy_to_cel_destination_rejected(self, explorer):
        # The same reservation applies to copy destinations.
        explorer.create_file("TestExplorer/source.txt")
        with pytest.raises(CelError, match="(?i)\\.cel extension is reserved"):
            explorer.copy("TestExplorer/source.txt", "TestExplorer/reserved.cel")

    def test_move_to_cel_destination_rejected(self, explorer):
        # Same gate covers non-interactive renames, which route through the
        # copy command in move mode.
        explorer.create_file("TestExplorer/source.txt")
        with pytest.raises(CelError, match="(?i)\\.cel extension is reserved"):
            explorer.move("TestExplorer/source.txt", "TestExplorer/reserved.cel")

    def test_copy_cel_source_reported_as_partial_failure(self, explorer, file, data):
        # A .cel sidecar must never be copied on its own; it would orphan or
        # duplicate the sidecar. The batch runs to completion and reports the
        # .cel source per-resource (partial_failure), so it does not raise; the
        # sidecar stays put and nothing lands at the destination.
        explorer.create_file("TestExplorer/notes.md")
        data.set_fields(
            "TestExplorer/notes.md",
            json.dumps({"priority": json.dumps("high")}),
        )

        result = explorer.copy(
            "TestExplorer/notes.md.cel",
            "TestExplorer/copy_target.txt",
        )

        assert result["status"] == "partial_failure"
        messages = " ".join(entry["message"] for entry in result["failedResources"])
        assert "reserved" in messages.lower()
        names = [i["name"] for i in file.list_contents("TestExplorer")]
        assert "copy_target.txt" not in names
        # The sidecar remains paired with its parent.
        assert file.get_info("TestExplorer/notes.md.cel")["type"] == "file"

    def test_move_cel_source_reported_as_partial_failure(self, explorer, file, data):
        # The same per-resource refusal applies to a move (rename) of a lone
        # sidecar key; the sidecar is not relocated.
        explorer.create_file("TestExplorer/notes.md")
        data.set_fields(
            "TestExplorer/notes.md",
            json.dumps({"priority": json.dumps("high")}),
        )

        result = explorer.move(
            "TestExplorer/notes.md.cel",
            "TestExplorer/moved_sidecar.txt",
        )

        assert result["status"] == "partial_failure"
        names = [i["name"] for i in file.list_contents("TestExplorer")]
        assert "moved_sidecar.txt" not in names
        assert file.get_info("TestExplorer/notes.md.cel")["type"] == "file"
